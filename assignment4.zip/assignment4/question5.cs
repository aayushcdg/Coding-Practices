﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace assignment4
{
    public partial class question5 : Form
    {
        private Timer timer;
        private int secLeft;
        public question5()
        {
            InitializeComponent();
            progressBar1.Value = 100;
            timer = new Timer();
            timer.Interval = 1000;
            timer.Tick += timer1_Tick;

            int sec = 10;
            secLeft = sec;

            lbl_time_left.Text = secLeft.ToString();
            timer.Start();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            finalResult form3 = new finalResult();

            if (radioButton1.Checked)
            {
                Form1.rightAnswers.Add(5);
                form3.ShowDialog();
                this.Close();

            }
            else
            {
                form3.ShowDialog();
                Form1.wrongAnswers.Add("5. It declares a new variable");
                this.Close();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            secLeft--;

            // Update the label with the updated remaining seconds
            lbl_time_left.Text = secLeft.ToString();

            if (secLeft <= 0)
            {
                timer.Stop();
                Close();
            }
        }
    }
}
