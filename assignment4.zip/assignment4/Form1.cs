﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace assignment4
{
    public partial class Form1 : Form
    {
        int countsLogin = 0;
        private Timer timer;
        public static List<int> rightAnswers = new List<int>();
        public static List<string> wrongAnswers = new List<string>();
        public Form1()
        {
            InitializeComponent();
            
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            timer.Stop();
            Close();
        }

        private void btn_submit_Click(object sender, EventArgs e)
        {
            if (txt_userName.Text.ToString() != "")
            {
                if(txt_pass.Text.ToString() == "4seneca")
                {
                    Form2 form = new Form2();
                    form.ShowDialog();
                }
                else
                {
                    countsLogin++;
                    if (countsLogin == 3)
                    {
                        lbl_error.Visible = true;
                        lbl_error.Text = "Finished all the attempts to put correct password";
                        timer = new Timer();
                        timer.Interval = 5000; // 5000 milliseconds = 5 seconds
                        timer.Tick += Timer_Tick;
                        timer.Start();
                    }
                    txt_pass.Clear();
                    txt_userName.Clear();
                }
            }
        }
    }
}
