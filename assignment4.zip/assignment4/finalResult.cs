﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace assignment4
{
    public partial class finalResult : Form
    {
        public finalResult()
        {
            InitializeComponent();
        }

        private void finalResult_Load(object sender, EventArgs e)
        {
            rightAns.Text = string.Join("\n", Form1.rightAnswers);
            wrongAns.Text = string.Join("\n", Form1.wrongAnswers);
            Form1.rightAnswers.Clear();
            Form1.wrongAnswers.Clear();
        }
    }
}
