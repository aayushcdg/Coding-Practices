﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace assignment4
{
    public partial class question2 : Form
    {
        private Timer timer;
        private int secLeft;
        public question2()
        {
            InitializeComponent();
            progressBar1.Value = 25;
            timer = new Timer();
            timer.Interval = 1000;
            timer.Tick += timer1_Tick;

            int sec = 10;
            secLeft = sec;

            lbl_time_left.Text = secLeft.ToString();
            timer.Start();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            question3cs form3 = new question3cs();

            if (radioButton1.Checked)
            {
                Form1.rightAnswers.Add(2);
                form3.ShowDialog();
                this.Close();
            }
            else
            {
                form3.ShowDialog();
                Form1.wrongAnswers.Add("2. int x = 10; ");
                this.Close();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            secLeft--;

            // Update the label with the updated remaining seconds
            lbl_time_left.Text = secLeft.ToString();

            if (secLeft <= 0)
            {
                timer.Stop();
                Close();
            }
        }
    }
}
